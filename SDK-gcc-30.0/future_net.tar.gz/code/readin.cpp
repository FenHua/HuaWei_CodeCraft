#include"stdio.h"
#include"readin.h"
#include"iostream"
#include"string"
#include"fstream"
#include<sstream>
using namespace std;
int d_num = 0;//Ҫ��ع�������
int totalline = 0;
int start;
int dest;
int Data[4800][4];
int d_Data[50];
int Get_D_Data(const char*filename)
{
	/*******************demand���ݼ�Ҫ��******************/
	char*Inf;
	string value;
	FILE *fp = fopen(filename, "r");
	if (!fp)
	{
		cout << "This file can't open !";
		return 0;
	}
	char line[5000];
	fgets(line,5000, fp);//����������
	Inf = strtok(line, ",");
	if (Inf != NULL)
		start = atoi(Inf);
	Inf = strtok(NULL, ",");
	if (Inf != NULL)
		dest = atoi(Inf);
	Inf = strtok(NULL, "|");
	while (Inf != NULL)
	{
		d_Data[d_num] = atoi(Inf);
		Inf = strtok(NULL, "|");
		d_num++;
	}
	fclose(fp);
	return 0;
}
/*************���ݶ�ȡ**********/
int Get_Data(const char*filename)
{
	ifstream file;
	file.open(filename);
	string  file_line, number; //��ȡ��һ���ı�
	if (file.fail() || file.eof())//�ж������ļ��Ƿ�ϸ�
	{
		cout << "can't open this file" << endl;
		return 0;
	}
	int v;
	while (std::getline(file, file_line))
	{
		int num = 0;
		istringstream is(file_line);
		while (std::getline(is, number, ','))
		{

			v = atoi(number.c_str());
			Data[totalline][num] = v;
			num++;
		}
		totalline++;
	}
	file.clear();
	file.close();
	return totalline;
}
