#include <stdio.h>
#include <sys/timeb.h>
void print_time(const char *head);
